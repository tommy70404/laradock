docker-compose up -d nginx php-fpm mysql influxdb grafana

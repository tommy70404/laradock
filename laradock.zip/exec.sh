docker-compose exec workspace bash

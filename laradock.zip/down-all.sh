docker stop $(docker ps -aq)
